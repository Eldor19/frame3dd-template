icons from
http://www.iconsplace.com/navy-icons/weight-icon
https://www.flaticon.com/search?word=air
